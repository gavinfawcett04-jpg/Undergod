# MLB Prop Finder (v2.1)

Pulls today's MLB schedule, projects pitcher AND hitter outcomes for every
common Underdog/sportsbook prop type, applies park-factor adjustments, and
auto-suggests the best parlay combinations.

---

## What's new in v2.1

- **Park factors** — Coors boosts HR rate ×1.38, Petco suppresses ×0.85,
  Yankee Stadium ×1.18, etc. Applied per-PA. Edit `parks.py` to override.
- **`--auto-bets` mode** — projects + suggests top picks and parlay combos
  with no `lines.csv` required. Best for a quick morning slate scan.
- **Parlay analyzer** — combined probability, per-leg breakeven, EV per $1
  at standard Underdog payouts (2-pick: 3x, 3-pick: 6x, 4-pick: 10x, 5-pick: 20x).
- **De-correlation** — auto-suggester caps at 1 leg per game so two batters
  in the same lineup don't compound (they're positively correlated).
- **Better lineup diagnostics** — explicit per-team status during fetch.

---

## How accurate is this, actually

A retail Python tool will not beat sharp Vegas lines on average. Sportsbooks
hire quants with real-time pitch data, injury intel, and sharp betting market
signal we don't have. What we CAN do is:

1. Match them on most lines (~80-85% of the time).
2. Find spots they haven't sharpened — low-volume markets, niche props,
   sleepy weekday afternoon games.
3. Process the slate fast so you only manually research the leans, not
   every game.

Treat the model output as a *first filter*, not a final answer. Cross-check
the leans against your own knowledge (lineup news, weather, ump assignments).

---

## Setup (one time)

```bash
git clone https://github.com/gavinfawcett04-jpg/Undergod.git
cd Undergod
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Daily workflow

```bash
source .venv/bin/activate

# Quick scan — see top picks + suggested parlays at common Underdog lines
python3 mlb_prop_finder.py --auto-bets

# OR — get player IDs, build lines.csv from real Underdog lines, then:
python3 mlb_prop_finder.py --dump-ids
# (build lines.csv)
python3 mlb_prop_finder.py --lines lines.csv --parlay
```

⚠ **Lineups post 2-3 hours before first pitch.** If you run early, the tool
falls back to the team's last-game lineup as a prediction (marked with `*`).
Re-run within ~3hr of first pitch for the real lineups.

---

## All flags

| Flag | What it does |
|------|--------------|
| `--auto-bets` | Project + suggest top picks at common lines, no CSV needed |
| `--lines lines.csv` | Evaluate your specific lines |
| `--parlay` | Generate parlay suggestions from `--lines` results |
| `--dump-ids` | Print all player IDs and exit |
| `--date 2026-04-22` | Different date |
| `--pitchers-only` / `--hitters-only` | Skip one side |
| `--no-park-factors` | Disable park-factor adjustment |
| `--underdog-threshold 0.55` | Lean threshold for Underdog (default 55%) |
| `--min-edge 0.05` | Sportsbook edge to flag (default 5%) |
| `--n-sims 10000` | Monte Carlo iterations |

---

## Underdog parlay math

Standard Higher/Lower payouts (no insurance):

| Picks | Payout | Per-leg breakeven |
|-------|--------|-------------------|
| 2     | 3x     | 57.7%             |
| 3     | 6x     | 55.0%             |
| 4     | 10x    | 56.2%             |
| 5     | 20x    | 54.9%             |

Per-leg breakeven = (1 / payout) ^ (1/N). Above that geometric mean, the
parlay is +EV under the independence assumption.

**The independence assumption is the catch.** Two hits props on hitters in
the same team's lineup are *positively correlated* — both hits more likely
when the offense is clicking. Same-game stacks therefore overstate EV. The
auto-suggester limits to 1 leg per game to dodge most of this.

---

## What the model does NOT yet account for

- Weather (cold suppresses HRs ~10%, wind out boosts ~15%) — v3
- Umpire K-zone (some umps add +5% K rate) — v3
- Pitcher recent workload (high pitch count = shorter outing) — v3
- Bullpen-specific quality (uses league-average) — v3
- Real-time injury news (check manually before betting)

---

## Honest reminder

Hitter projections have huge variance. A hitter going 0-for-4 vs your "70%
to get a hit" projection is normal. Don't trust the model until you've
logged 50+ predictions vs actual results and confirmed calibration. Until
then this is a research tool, not a green light.

---

## File map

```
Undergod/
├── mlb_prop_finder.py    # CLI orchestrator
├── data.py               # MLB Stats API + Statcast fetchers
├── simulator.py          # vectorized per-PA Monte Carlo
├── props.py              # prop registry, lines, EV, parlay analyzer
├── output.py             # formatted table printers
├── parks.py              # MLB ballpark factors (edit to taste)
├── requirements.txt
├── sample_lines.csv
└── README.md
```

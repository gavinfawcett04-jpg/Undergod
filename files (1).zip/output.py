"""
output.py — pretty-printed tables.
"""

from __future__ import annotations

from props import PropResult


def print_pitcher_projections(rows: list[dict]) -> None:
    if not rows:
        return
    print(f"\n{'PITCHER':<24}{'TM':<5}{'OPP':<5}{'H':<3}"
          f"{'IP':>5}{'BF':>5}{'xK':>6}{'xBB':>6}{'xH':>6}{'xER':>6}")
    print("-" * 71)
    rows_sorted = sorted(rows, key=lambda r: r['xK'], reverse=True)
    for r in rows_sorted:
        print(f"{r['name']:<24}{r['team']:<5}{r['opp']:<5}{r['hand']:<3}"
              f"{r['ip']:>5.1f}{r['bf']:>5.1f}"
              f"{r['xK']:>6.2f}{r['xBB']:>6.2f}"
              f"{r['xH']:>6.2f}{r['xER']:>6.2f}")


def print_hitter_projections(rows: list[dict]) -> None:
    if not rows:
        return
    print(f"\n{'HITTER':<24}{'TM':<5}{'OPP':<5}{'BO':>3}"
          f"{'PA':>5}{'xH':>5}{'xTB':>6}{'xHR':>6}{'xRBI':>6}{'xR':>5}{'xK':>5}")
    print("-" * 75)
    rows_sorted = sorted(rows, key=lambda r: r['xTB'], reverse=True)
    for r in rows_sorted:
        flag = " *" if r.get('predicted') else "  "
        print(f"{r['name']:<24}{r['team']:<5}{r['opp']:<5}{r['order']:>3}"
              f"{r['pa']:>5.1f}{r['xH']:>5.2f}{r['xTB']:>6.2f}"
              f"{r['xHR']:>6.2f}{r['xRBI']:>6.2f}{r['xR']:>5.2f}{r['xK']:>5.2f}"
              f"{flag}")
    if any(r.get('predicted') for r in rows_sorted):
        print("\n  * = lineup not posted yet, using last game's order as prediction")


def print_evaluations(results: list[PropResult],
                      min_edge: float = 0.05,
                      underdog_threshold: float = 0.55) -> None:
    if not results:
        return

    has_odds = any(r.over_odds is not None for r in results)

    if has_odds:
        # Sportsbook view
        evs = sorted([r for r in results if r.over_odds is not None],
                     key=lambda r: (r.best_edge_vs_implied or -1), reverse=True)
        print(f"\n{'─' * 4} SPORTSBOOK EV {'─' * 4}")
        print(f"{'PLAYER':<22}{'PROP':<14}{'LINE':>6}{'PROJ':>6}"
              f"{'SIDE':>6}{'EDGE':>8}{'EV':>8}")
        print("-" * 70)
        for r in evs:
            flag = " ★" if (r.best_edge_vs_implied or 0) >= min_edge \
                          and r.best_side != 'PASS' else "  "
            edge = r.best_edge_vs_implied or 0
            ev   = r.best_ev_per_unit or 0
            print(f"{r.player_name:<22}{r.prop_type:<14}"
                  f"{r.line:>6.1f}{r.proj_mean:>6.2f}"
                  f"{r.best_side:>6}{edge:>+7.1%}{ev:>+7.2f}{flag}")
        print(f"\n  ★ = sportsbook edge >= {min_edge:.0%}")

    # Underdog view (always)
    uds = sorted(results, key=lambda r: r.edge_vs_50, reverse=True)
    print(f"\n{'─' * 4} UNDERDOG PICK'EM {'─' * 4}")
    print(f"{'PLAYER':<22}{'PROP':<14}{'LINE':>6}{'PROJ':>6}"
          f"{'PICK':>6}{'P(WIN)':>8}{'EDGE':>8}")
    print("-" * 72)
    for r in uds:
        win_prob = max(r.p_over, r.p_under)
        flag = " ★" if win_prob >= underdog_threshold else "  "
        print(f"{r.player_name:<22}{r.prop_type:<14}"
              f"{r.line:>6.1f}{r.proj_mean:>6.2f}"
              f"{r.underdog_pick:>6}{win_prob:>7.1%}"
              f"{r.edge_vs_50:>+7.1%}{flag}")
    print(f"\n  ★ = win prob >= {underdog_threshold:.0%} (Underdog lean threshold)")


def print_parlay_suggestions(suggestions: list[dict]) -> None:
    """Pretty-print auto-generated parlay suggestions."""
    if not suggestions:
        print("\nNo qualifying legs for parlay suggestions "
              "(try lowering --underdog-threshold).")
        return
    print(f"\n{'─' * 4} AUTO-PARLAY SUGGESTIONS {'─' * 4}")
    print("(One leg per game to reduce correlation.)\n")
    for s in suggestions:
        a = s['analysis']
        size = s['size']
        flag = " ★ +EV" if a['profitable'] else "   -EV"
        print(f"  {size}-PICK PARLAY  ({a['payout_x']}x payout){flag}")
        for leg in s['legs']:
            print(f"    • {leg.label:<55} {leg.prob:>6.1%}")
        print(f"    Combined: {a['combined_prob']:.1%}   "
              f"Need per-leg avg: {a['breakeven_per_leg']:.1%}   "
              f"EV per $1: ${a['ev_per_unit']:+.2f}")
        print()

"""
props.py — prop type registry and EV evaluation against simulated distributions.

A "prop" is a (player, prop_type, line) tuple.  Each prop_type maps to a key
in the simulation result dict (e.g. 'hits', 'strikeouts').

Two evaluation framings are supported:
  - Sportsbook: user supplies American odds; we compute edge vs implied prob
                and EV per 1-unit stake.
  - Underdog pick'em: user supplies no odds (or equal odds); we compute edge
                vs 50% — the threshold sharp Underdog players use is ≥55%.
"""

from __future__ import annotations

import csv
import sys
from dataclasses import dataclass
from typing import Optional

import numpy as np


PITCHER_PROPS = {
    'strikeouts', 'walks', 'hits_allowed', 'outs', 'earned_runs',
    # aliases for convenience:
    'ks', 'k', 'bb', 'h_allowed', 'pitcher_outs', 'er',
}
HITTER_PROPS = {
    'hits', 'home_runs', 'singles', 'extra_base_hits', 'total_bases',
    'strikeouts', 'walks', 'rbis', 'runs', 'hits_runs_rbis',
    # aliases:
    'h', 'hr', 'tb', 'xbh', 'r', 'rbi', 'bb', 'k', 'ks', 'hrr',
}

PROP_ALIASES = {
    'ks': 'strikeouts', 'k': 'strikeouts',
    'bb': 'walks',
    'h_allowed': 'hits_allowed', 'pitcher_outs': 'outs', 'er': 'earned_runs',
    'h': 'hits', 'hr': 'home_runs', 'tb': 'total_bases',
    'xbh': 'extra_base_hits',
    'r': 'runs', 'rbi': 'rbis',
    'hrr': 'hits_runs_rbis',
}


def normalize_prop_type(s: str) -> str:
    s = s.strip().lower().replace(' ', '_').replace('-', '_')
    return PROP_ALIASES.get(s, s)


@dataclass
class PropLine:
    player_id:  int
    prop_type:  str       # normalized
    line:       float
    over_odds:  Optional[int]  # None => Underdog/pick'em
    under_odds: Optional[int]


@dataclass
class PropResult:
    player_id:  int
    player_name: str
    matchup:    str         # e.g. "LAD vs SF"
    game_pk:    int
    prop_type:  str
    line:       float
    proj_mean:  float
    p_over:     float
    p_under:    float
    # sportsbook framing (None if no odds)
    over_odds:  Optional[int]
    under_odds: Optional[int]
    over_edge:  Optional[float]
    under_edge: Optional[float]
    best_side:  str         # 'OVER' / 'UNDER' / 'PASS'
    best_edge_vs_implied: Optional[float]
    best_ev_per_unit:     Optional[float]
    # Underdog framing (always populated)
    edge_vs_50: float       # max(p_over, p_under) - 0.5
    underdog_pick: str      # 'OVER' / 'UNDER' / 'PASS'

    @property
    def win_prob(self) -> float:
        return max(self.p_over, self.p_under)


# Standard Underdog Pick'em "Higher/Lower" payouts (no insurance).
# Override via --underdog-payouts on the CLI if these change.
UNDERDOG_PAYOUTS = {2: 3.0, 3: 6.0, 4: 10.0, 5: 20.0, 6: 35.0}


# ---------------------------------------------------------------------------
# Probability calc
# ---------------------------------------------------------------------------
def prob_over(dist: np.ndarray, line: float) -> float:
    """For line 1.5, count sims where outcome >= 2."""
    threshold = int(np.ceil(line))
    if line == int(line):
        # Pushed: skip half lines convention — treat line N as need >= N+1
        threshold = int(line) + 1
    return float((dist >= threshold).mean())


# ---------------------------------------------------------------------------
# Odds math
# ---------------------------------------------------------------------------
def american_to_decimal(odds: int) -> float:
    return 1 + (odds / 100 if odds > 0 else 100 / -odds)

def implied_prob(odds: int) -> float:
    return 1.0 / american_to_decimal(odds)


# ---------------------------------------------------------------------------
# Evaluation
# ---------------------------------------------------------------------------
def evaluate_prop(
    line: PropLine,
    dist: np.ndarray,
    player_name: str,
    matchup: str,
    game_pk: int = 0,
    underdog_threshold: float = 0.55,
) -> PropResult:
    p_over = prob_over(dist, line.line)
    p_under = 1.0 - p_over
    proj_mean = float(dist.mean())

    # Underdog framing
    if p_over >= p_under:
        ud_pick = 'OVER' if p_over >= underdog_threshold else 'PASS'
        edge_50 = p_over - 0.5
    else:
        ud_pick = 'UNDER' if p_under >= underdog_threshold else 'PASS'
        edge_50 = p_under - 0.5

    # Sportsbook framing
    over_edge = under_edge = None
    best_side = 'PASS'
    best_edge_implied = None
    best_ev = None
    if line.over_odds is not None and line.under_odds is not None:
        over_edge  = p_over  - implied_prob(line.over_odds)
        under_edge = p_under - implied_prob(line.under_odds)
        if over_edge >= under_edge and over_edge > 0:
            best_side = 'OVER'
            best_edge_implied = over_edge
            best_ev = (p_over * (american_to_decimal(line.over_odds) - 1)
                       - (1 - p_over))
        elif under_edge > 0:
            best_side = 'UNDER'
            best_edge_implied = under_edge
            best_ev = (p_under * (american_to_decimal(line.under_odds) - 1)
                       - (1 - p_under))
        else:
            best_edge_implied = max(over_edge, under_edge)
            best_ev = 0.0

    return PropResult(
        player_id   = line.player_id,
        player_name = player_name,
        matchup     = matchup,
        game_pk     = game_pk,
        prop_type   = line.prop_type,
        line        = line.line,
        proj_mean   = proj_mean,
        p_over      = p_over,
        p_under     = p_under,
        over_odds   = line.over_odds,
        under_odds  = line.under_odds,
        over_edge   = over_edge,
        under_edge  = under_edge,
        best_side   = best_side,
        best_edge_vs_implied = best_edge_implied,
        best_ev_per_unit     = best_ev,
        edge_vs_50  = edge_50,
        underdog_pick = ud_pick,
    )


# ---------------------------------------------------------------------------
# Parlay analysis
# ---------------------------------------------------------------------------
@dataclass
class ParlayLeg:
    label: str        # human-readable
    prob:  float
    game_pk: int = 0


def analyze_parlay(legs: list[ParlayLeg], payout_x: float) -> dict:
    """
    Combined parlay probability under independence assumption + EV math.

    payout_x = decimal multiplier on a winning ticket (e.g. 6.0 for Underdog
    3-pick). EV per $1 stake = combined_prob * payout_x - 1.
    """
    if not legs:
        return {}
    n = len(legs)
    combined = float(np.prod([l.prob for l in legs]))
    breakeven_combined = 1.0 / payout_x
    breakeven_per_leg  = breakeven_combined ** (1.0 / n)
    ev = combined * payout_x - 1.0
    return {
        'n_legs':            n,
        'combined_prob':     combined,
        'payout_x':          payout_x,
        'breakeven_per_leg': breakeven_per_leg,
        'ev_per_unit':       ev,
        'profitable':        ev > 0,
    }


def suggest_parlays(
    results: list[PropResult],
    sizes: tuple = (2, 3, 4, 5),
    max_per_game: int = 1,
    min_prob: float = 0.55,
    payouts: dict[int, float] = None,
) -> list[dict]:
    """
    Auto-build the highest-probability parlays at each parlay size,
    diversifying across games to avoid same-game correlation.
    """
    if payouts is None:
        payouts = UNDERDOG_PAYOUTS

    confident = sorted(
        [r for r in results if r.win_prob >= min_prob],
        key=lambda r: r.win_prob, reverse=True,
    )

    # Greedy de-correlation: cap legs per game
    by_game: dict[int, int] = {}
    selected: list[PropResult] = []
    for r in confident:
        if by_game.get(r.game_pk, 0) >= max_per_game:
            continue
        selected.append(r)
        by_game[r.game_pk] = by_game.get(r.game_pk, 0) + 1

    out = []
    for size in sizes:
        if len(selected) < size:
            continue
        legs = selected[:size]
        parlay_legs = [
            ParlayLeg(
                label=f"{r.player_name} {r.prop_type} {r.line} {r.underdog_pick}",
                prob=r.win_prob,
                game_pk=r.game_pk,
            )
            for r in legs
        ]
        analysis = analyze_parlay(parlay_legs, payouts.get(size, 1.0))
        out.append({
            'size':     size,
            'legs':     parlay_legs,
            'analysis': analysis,
        })
    return out


# ---------------------------------------------------------------------------
# CSV loader
# ---------------------------------------------------------------------------
def load_lines(path: str) -> list[PropLine]:
    """
    CSV columns:
        player_id, prop_type, line, [over_odds], [under_odds]
    Empty / missing odds columns mean Underdog framing.
    """
    out: list[PropLine] = []
    with open(path) as f:
        reader = csv.DictReader(f)
        for row in reader:
            try:
                pid       = int(row['player_id'])
                prop_type = normalize_prop_type(row['prop_type'])
                line_val  = float(row['line'])
            except (KeyError, ValueError) as e:
                print(f"  [warn] skipping bad row {row}: {e}", file=sys.stderr)
                continue
            over  = row.get('over_odds', '').strip()
            under = row.get('under_odds', '').strip()
            over_odds  = int(over)  if over  else None
            under_odds = int(under) if under else None
            out.append(PropLine(
                player_id=pid, prop_type=prop_type, line=line_val,
                over_odds=over_odds, under_odds=under_odds,
            ))
    return out

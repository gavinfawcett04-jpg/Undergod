#!/usr/bin/env python3
"""
MLB Player Prop Finder — v2.1

Pulls today's MLB schedule, projects pitcher AND hitter outcomes for every
common Underdog/sportsbook prop type, applies park-factor adjustments, and
auto-suggests the best parlay combinations.

Usage:
    python mlb_prop_finder.py                              # Just projections
    python mlb_prop_finder.py --auto-bets                  # Suggest top picks + parlays
    python mlb_prop_finder.py --lines lines.csv            # Evaluate your specific lines
    python mlb_prop_finder.py --lines lines.csv --parlay   # Eval + parlay suggestions
    python mlb_prop_finder.py --dump-ids                   # Just print player IDs

    --date 2026-04-22         pick a different date
    --pitchers-only           skip hitters
    --hitters-only            skip pitchers
    --no-park-factors         disable park-factor adjustment
    --underdog-threshold 0.55 lean threshold for Underdog
    --min-edge 0.05           sportsbook edge to flag
    --n-sims 10000            Monte Carlo iterations
"""

from __future__ import annotations

import argparse
import sys
from datetime import date, datetime

import numpy as np

import data
import simulator as sim
import props
import output
import parks


COMMON_LINES = {
    'pitcher': {
        'walks':        1.5,
        'earned_runs':  2.5,
    },
    'hitter': {
        'hits':            0.5,
        'total_bases':     1.5,
        'home_runs':       0.5,
        'rbis':            0.5,
        'runs':            0.5,
        'hits_runs_rbis':  1.5,
        'singles':         0.5,
        'extra_base_hits': 0.5,
        'strikeouts':      0.5,
        'walks':           0.5,
    },
}


def _common_line(proj_mean: float, prop_type: str, kind: str) -> float:
    """Hardcoded common Underdog line, or proj_mean rounded to .5"""
    cfg = COMMON_LINES[kind].get(prop_type)
    if cfg is not None:
        return cfg
    return float(round(proj_mean * 2) / 2 - 0.5) if proj_mean > 1 else 0.5


def _eval_line(line, pitcher_dists, hitter_dists, p_lookup, h_lookup,
               p_gpk, h_gpk, ud_thresh) -> list:
    if line.player_id in pitcher_dists:
        dist_dict = pitcher_dists[line.player_id]
        p = p_lookup[line.player_id]
        name = p.pitcher_name
        matchup = f"{p.team} vs {p.opponent}"
        gpk = p_gpk[line.player_id]
    elif line.player_id in hitter_dists:
        dist_dict = hitter_dists[line.player_id]
        h = h_lookup[line.player_id]
        name = h.batter_name
        matchup = f"{h.team} vs {h.opponent}"
        gpk = h_gpk[line.player_id]
    else:
        return []
    if line.prop_type not in dist_dict:
        return []
    return [props.evaluate_prop(line, dist_dict[line.prop_type],
                                name, matchup, gpk, ud_thresh)]


def main() -> int:
    ap = argparse.ArgumentParser(description="MLB prop finder (v2.1)")
    ap.add_argument("--date",  help="YYYY-MM-DD (default today)")
    ap.add_argument("--lines", help="CSV of prop lines for EV calc")
    ap.add_argument("--auto-bets", action="store_true",
                    help="Suggest top picks at common lines + parlay suggestions")
    ap.add_argument("--parlay", action="store_true",
                    help="Generate parlay suggestions from --lines results")
    ap.add_argument("--min-edge", type=float, default=0.05)
    ap.add_argument("--underdog-threshold", type=float, default=0.55)
    ap.add_argument("--n-sims", type=int, default=10000)
    ap.add_argument("--pitchers-only", action="store_true")
    ap.add_argument("--hitters-only",  action="store_true")
    ap.add_argument("--no-park-factors", action="store_true")
    ap.add_argument("--dump-ids", action="store_true")
    args = ap.parse_args()

    target = (datetime.strptime(args.date, "%Y-%m-%d").date()
              if args.date else date.today())

    print(f"\n=== MLB Prop Finder v2.1 — {target} ===\n")
    use_park = not args.no_park_factors
    print(f"Park factors: {'ON' if use_park else 'OFF'}")

    print("\nFetching schedule + probable pitchers ...")
    pitchers = data.get_todays_pitchers(target)
    if not pitchers:
        print("No probable pitchers found.")
        return 0
    print(f"  {len(pitchers)} probable starters across "
          f"{len({p.game_pk for p in pitchers})} games.")

    hitters: list = []
    if not args.pitchers_only:
        print("\nFetching lineups (or predicted-lineup fallback) ...")
        hitters = data.get_todays_hitters(pitchers, target, verbose=True)
        if not hitters:
            print("\n  ⚠  No lineups available.  Hitter projections skipped.")
            print("     Re-run within ~3hr of first pitch for posted lineups.")

    if args.dump_ids:
        print("\n--- PITCHER IDS ---")
        for p in pitchers:
            print(f"{p.pitcher_id:<10}{p.pitcher_name:<25}{p.team} vs {p.opponent}")
        print("\n--- HITTER IDS ---")
        for h in hitters:
            tag = " (predicted)" if h.lineup_predicted else ""
            print(f"{h.batter_id:<10}{h.batter_name:<25}"
                  f"{h.team} vs {h.opponent}  BO{h.batting_order}{tag}")
        return 0

    print("\nComputing league baseline rates ...")
    league = data.compute_league_rates(target)
    print(f"  League: K%={league['k_rate']:.1%}, BB%={league['bb_rate']:.1%}, "
          f"HR%={league['hr_rate']:.1%}")

    rng = np.random.default_rng(42)

    pitcher_dists: dict = {}
    pitcher_game_pk: dict = {}
    pitcher_rows: list = []
    if not args.hitters_only:
        print("\nProjecting pitchers ...")
        for p in pitchers:
            print(f"  {p.pitcher_name} ({p.team})")
            P = data.get_pitcher_rates(p.pitcher_id, target, league)
            opp_k = data.get_opp_k_pct(p.opponent_id, p.handedness, target, league)
            opp_rates = {'k_rate': opp_k, 'bb_rate': league['bb_rate'],
                         'hr_rate': league['hr_rate']}
            park = parks.get_park_factors(p.home_team_id) if use_park else None
            probs = sim.pitcher_pa_probs(P, opp_rates, league, park=park)
            expected_bf = P.avg_ip * data.PA_PER_IP
            dist = sim.simulate_pitcher(probs, expected_bf, P.era_per_bf,
                                        n_sims=args.n_sims, rng=rng)
            pitcher_dists[p.pitcher_id] = dist
            pitcher_game_pk[p.pitcher_id] = p.game_pk
            pitcher_rows.append({
                'name': p.pitcher_name, 'team': p.team, 'opp': p.opponent,
                'hand': p.handedness, 'ip': P.avg_ip, 'bf': expected_bf,
                'xK': dist['strikeouts'].mean(), 'xBB': dist['walks'].mean(),
                'xH': dist['hits_allowed'].mean(), 'xER': dist['earned_runs'].mean(),
            })
        output.print_pitcher_projections(pitcher_rows)

    hitter_dists: dict = {}
    hitter_game_pk: dict = {}
    hitter_rows: list = []
    if not args.pitchers_only and hitters:
        print(f"\nProjecting {len(hitters)} hitters ...")
        opp_pitcher_rates: dict = {}
        for h in hitters:
            if h.opp_pitcher_id not in opp_pitcher_rates:
                opp_pitcher_rates[h.opp_pitcher_id] = data.get_pitcher_rates(
                    h.opp_pitcher_id, target, league)

        class _BP:
            k_rate  = league['k_rate']
            bb_rate = league['bb_rate']
            hr_rate = league['hr_rate']
            hits_per_bf = (league['1b_rate'] + league['2b_rate']
                           + league['3b_rate'] + league['hr_rate'])
        bullpen_p = _BP()

        for i, h in enumerate(hitters):
            if i % 25 == 0:
                print(f"  ... {i}/{len(hitters)}")
            B = data.get_hitter_rates(h.batter_id, target, league)
            P = opp_pitcher_rates[h.opp_pitcher_id]
            park = parks.get_park_factors(h.home_team_id) if use_park else None
            starter_probs = sim.hitter_pa_probs(B, P, league, park=park)
            bullpen_probs = sim.hitter_pa_probs(B, bullpen_p, league, park=park)
            exp_pa = sim.expected_pa(h.batting_order)
            dist = sim.simulate_hitter(starter_probs, bullpen_probs, exp_pa,
                                       B, n_sims=args.n_sims, rng=rng)
            hitter_dists[h.batter_id] = dist
            hitter_game_pk[h.batter_id] = h.game_pk
            hitter_rows.append({
                'name': h.batter_name, 'team': h.team, 'opp': h.opponent,
                'order': h.batting_order, 'pa': exp_pa,
                'xH': dist['hits'].mean(), 'xTB': dist['total_bases'].mean(),
                'xHR': dist['home_runs'].mean(), 'xRBI': dist['rbis'].mean(),
                'xR': dist['runs'].mean(), 'xK': dist['strikeouts'].mean(),
                'predicted': h.lineup_predicted,
            })
        output.print_hitter_projections(hitter_rows)

    # ------------------------------------------------------------------
    # Build PropResults from --lines, --auto-bets, or both
    # ------------------------------------------------------------------
    results: list = []
    pitcher_lookup = {p.pitcher_id: p for p in pitchers}
    hitter_lookup  = {h.batter_id: h for h in hitters}

    if args.lines:
        try:
            lines = props.load_lines(args.lines)
        except FileNotFoundError:
            print(f"\nERROR: lines file not found: {args.lines}", file=sys.stderr)
            return 1
        for line in lines:
            results.extend(_eval_line(
                line, pitcher_dists, hitter_dists, pitcher_lookup,
                hitter_lookup, pitcher_game_pk, hitter_game_pk,
                args.underdog_threshold))

    if args.auto_bets:
        pitcher_ptypes = ['strikeouts', 'walks', 'earned_runs',
                          'hits_allowed', 'outs']
        hitter_ptypes  = ['hits', 'total_bases', 'home_runs', 'rbis',
                          'runs', 'hits_runs_rbis']
        for pid, dist_dict in pitcher_dists.items():
            for ptype in pitcher_ptypes:
                if ptype not in dist_dict: continue
                line_val = _common_line(float(dist_dict[ptype].mean()),
                                        ptype, 'pitcher')
                synthetic = props.PropLine(player_id=pid, prop_type=ptype,
                                           line=line_val, over_odds=None,
                                           under_odds=None)
                results.extend(_eval_line(
                    synthetic, pitcher_dists, hitter_dists,
                    pitcher_lookup, hitter_lookup,
                    pitcher_game_pk, hitter_game_pk,
                    args.underdog_threshold))
        for hid, dist_dict in hitter_dists.items():
            for ptype in hitter_ptypes:
                if ptype not in dist_dict: continue
                line_val = _common_line(float(dist_dict[ptype].mean()),
                                        ptype, 'hitter')
                synthetic = props.PropLine(player_id=hid, prop_type=ptype,
                                           line=line_val, over_odds=None,
                                           under_odds=None)
                results.extend(_eval_line(
                    synthetic, pitcher_dists, hitter_dists,
                    pitcher_lookup, hitter_lookup,
                    pitcher_game_pk, hitter_game_pk,
                    args.underdog_threshold))

    if results:
        output.print_evaluations(results, args.min_edge,
                                 args.underdog_threshold)

    if args.parlay or args.auto_bets:
        suggestions = props.suggest_parlays(
            results, sizes=(2, 3, 4, 5),
            min_prob=args.underdog_threshold,
        )
        output.print_parlay_suggestions(suggestions)
        if suggestions:
            print("  ⚠  Parlay math assumes legs are INDEPENDENT.")
            print("     Same-game stacks (especially HR + RBI on same team)")
            print("     are POSITIVELY correlated; suggested EV overstates.")
            print("     Auto-suggester caps at 1 leg per game to reduce this.")

    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())

"""
parks.py - MLB ballpark factors.

1.00 = league average. Values above 1 = ballpark boosts that outcome.
Approximations from public 3-year park factor data (Statcast / FanGraphs).

For 2025-2026 the Athletics play at Sutter Health Park (Sacramento, AAA)
and the Rays at Steinbrenner Field (Yankees ST). Both are smaller and
more hitter-friendly than their previous homes — adjusted accordingly.

Edit these freely if you have better data.
"""

# Keyed by HOME team's MLB Stats API team_id.
PARK_FACTORS: dict[int, dict[str, float]] = {
    108: {'hr': 1.02, 'h': 0.99, 'k': 1.00},  # Angels - Angel Stadium
    109: {'hr': 1.05, 'h': 1.02, 'k': 0.98},  # Diamondbacks - Chase Field
    110: {'hr': 0.95, 'h': 0.98, 'k': 1.00},  # Orioles - Camden Yards
    111: {'hr': 0.95, 'h': 1.06, 'k': 0.98},  # Red Sox - Fenway (Monster boosts hits/2B)
    112: {'hr': 1.02, 'h': 1.00, 'k': 1.00},  # Cubs - Wrigley (varies w/ wind)
    113: {'hr': 1.18, 'h': 1.04, 'k': 0.97},  # Reds - Great American
    114: {'hr': 1.00, 'h': 0.98, 'k': 1.00},  # Guardians - Progressive
    115: {'hr': 1.38, 'h': 1.10, 'k': 0.96},  # Rockies - COORS FIELD (altitude)
    116: {'hr': 0.92, 'h': 0.97, 'k': 1.02},  # Tigers - Comerica
    117: {'hr': 1.02, 'h': 1.00, 'k': 1.00},  # Astros - Minute Maid
    118: {'hr': 0.95, 'h': 1.03, 'k': 0.99},  # Royals - Kauffman
    119: {'hr': 1.02, 'h': 0.98, 'k': 1.00},  # Dodgers - Dodger Stadium
    120: {'hr': 1.00, 'h': 1.00, 'k': 1.00},  # Nationals - Nationals Park
    121: {'hr': 0.95, 'h': 0.98, 'k': 1.00},  # Mets - Citi Field
    133: {'hr': 1.05, 'h': 1.05, 'k': 0.98},  # A's - Sutter Health Park (Sac, 2025-27)
    134: {'hr': 0.95, 'h': 1.00, 'k': 1.01},  # Pirates - PNC
    135: {'hr': 0.85, 'h': 0.95, 'k': 1.02},  # Padres - PETCO (suppresses HR)
    136: {'hr': 0.92, 'h': 0.95, 'k': 1.04},  # Mariners - T-Mobile (favors pitchers)
    137: {'hr': 0.80, 'h': 0.95, 'k': 1.02},  # Giants - ORACLE PARK (suppresses HR)
    138: {'hr': 0.95, 'h': 1.00, 'k': 1.00},  # Cardinals - Busch
    139: {'hr': 1.10, 'h': 1.02, 'k': 0.98},  # Rays - Steinbrenner Field (2025+)
    140: {'hr': 1.10, 'h': 1.02, 'k': 0.98},  # Rangers - Globe Life
    141: {'hr': 1.05, 'h': 1.02, 'k': 0.99},  # Blue Jays - Rogers Centre
    142: {'hr': 1.00, 'h': 1.02, 'k': 1.00},  # Twins - Target Field
    143: {'hr': 1.13, 'h': 1.02, 'k': 0.98},  # Phillies - Citizens Bank
    144: {'hr': 1.05, 'h': 1.01, 'k': 1.00},  # Braves - Truist
    145: {'hr': 1.05, 'h': 1.00, 'k': 1.00},  # White Sox - Rate Field
    146: {'hr': 0.92, 'h': 0.97, 'k': 1.01},  # Marlins - loanDepot
    147: {'hr': 1.18, 'h': 1.02, 'k': 0.99},  # Yankees - Yankee Stadium
    158: {'hr': 1.05, 'h': 1.01, 'k': 1.00},  # Brewers - American Family
}

DEFAULT = {'hr': 1.00, 'h': 1.00, 'k': 1.00}

def get_park_factors(home_team_id: int) -> dict[str, float]:
    return PARK_FACTORS.get(home_team_id, DEFAULT).copy()

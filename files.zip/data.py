"""
data.py — MLB data fetching layer.

All Statcast pulls are cached on disk by pybaseball.  The league-wide pull
(used to compute opponent rates and league constants) is the slowest call;
it's cached at module level after the first run.
"""

from __future__ import annotations

import sys
from dataclasses import dataclass, field
from datetime import date, timedelta
from typing import Optional

import numpy as np
import pandas as pd
import requests

try:
    from pybaseball import statcast, statcast_pitcher, statcast_batter, cache
    cache.enable()
except ImportError:
    print("ERROR: pybaseball not installed.  Run:  pip install -r requirements.txt",
          file=sys.stderr)
    sys.exit(1)


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
MLB_BASE             = "https://statsapi.mlb.com/api/v1"
LOOKBACK_DAYS        = 45
PRIOR_PA_BATTER      = 80      # shrinkage prior for hitter rates
PRIOR_BF_PITCHER     = 150     # shrinkage prior for pitcher rates
DEFAULT_IP           = 5.5
PA_PER_IP            = 4.3

# These get overwritten with measured league rates after first Statcast pull
LEAGUE_RATES_DEFAULT = {
    'k_rate':     0.226,
    'bb_rate':    0.085,
    'hr_rate':    0.030,
    '1b_rate':    0.140,
    '2b_rate':    0.044,
    '3b_rate':    0.004,
    'bip_out':    0.471,
}

K_EVENTS    = {"strikeout", "strikeout_double_play"}
BB_EVENTS   = {"walk"}
HR_EVENTS   = {"home_run"}
S1_EVENTS   = {"single"}
S2_EVENTS   = {"double"}
S3_EVENTS   = {"triple"}
HBP_EVENTS  = {"hit_by_pitch"}
OUT_EVENTS  = {
    "field_out", "force_out", "grounded_into_double_play", "double_play",
    "sac_fly", "sac_bunt", "sac_fly_double_play", "fielders_choice_out",
    "triple_play", "fielders_choice",
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------
@dataclass
class GamePitcher:
    pitcher_id:   int
    pitcher_name: str
    team:         str
    opponent:     str
    opponent_id:  int
    handedness:   str       # 'R' or 'L'
    home:         bool
    game_pk:      int


@dataclass
class GameHitter:
    batter_id:   int
    batter_name: str
    team:        str
    opponent:    str
    opp_pitcher_id: int
    opp_pitcher_hand: str
    batting_order: int      # 1-9
    home: bool
    game_pk: int
    lineup_predicted: bool  # True if lineup wasn't actually posted yet


@dataclass
class PitcherRates:
    k_rate:     float
    bb_rate:    float
    hr_rate:    float
    hits_per_bf: float
    era_per_bf: float       # earned runs per batter faced
    avg_ip:     float       # rolling avg IP per start
    n_bf:       int


@dataclass
class HitterRates:
    k_rate:    float
    bb_rate:   float
    hr_rate:   float
    s1_rate:   float
    s2_rate:   float
    s3_rate:   float
    bip_out:   float
    rbi_per_pa: float
    r_per_pa:   float
    n_pa:      int


# ---------------------------------------------------------------------------
# League-wide Statcast pull (used for opponent rates + league baselines)
# ---------------------------------------------------------------------------
_league_df_cache: dict[tuple[str, str], pd.DataFrame] = {}

def get_league_df(end: date, window: int = LOOKBACK_DAYS) -> pd.DataFrame:
    """Pull all Statcast pitches over the rolling window.  Cached per call."""
    start_s = (end - timedelta(days=window)).strftime("%Y-%m-%d")
    end_s   = end.strftime("%Y-%m-%d")
    key = (start_s, end_s)
    if key in _league_df_cache:
        return _league_df_cache[key]
    print(f"  Pulling league-wide Statcast {start_s} -> {end_s} ...")
    try:
        df = statcast(start_dt=start_s, end_dt=end_s)
    except Exception as e:
        print(f"  [error] league statcast failed: {e}", file=sys.stderr)
        df = pd.DataFrame()
    _league_df_cache[key] = df
    return df


def pa_terminals(df: pd.DataFrame) -> pd.DataFrame:
    return df[df["events"].notna() & (df["events"] != "")].copy()


# ---------------------------------------------------------------------------
# League rates from the same window (more accurate than hardcoded constants)
# ---------------------------------------------------------------------------
def compute_league_rates(end: date) -> dict[str, float]:
    df = get_league_df(end)
    if df.empty:
        return LEAGUE_RATES_DEFAULT.copy()
    pa = pa_terminals(df)
    if pa.empty:
        return LEAGUE_RATES_DEFAULT.copy()
    n = len(pa)
    return {
        'k_rate':  pa["events"].isin(K_EVENTS).sum()  / n,
        'bb_rate': pa["events"].isin(BB_EVENTS).sum() / n,
        'hr_rate': pa["events"].isin(HR_EVENTS).sum() / n,
        '1b_rate': pa["events"].isin(S1_EVENTS).sum() / n,
        '2b_rate': pa["events"].isin(S2_EVENTS).sum() / n,
        '3b_rate': pa["events"].isin(S3_EVENTS).sum() / n,
        'bip_out': pa["events"].isin(OUT_EVENTS).sum() / n,
    }


# ---------------------------------------------------------------------------
# Schedule + probable pitchers
# ---------------------------------------------------------------------------
def get_todays_pitchers(target_date: date) -> list[GamePitcher]:
    params = {
        "sportId":  1,
        "date":     target_date.strftime("%Y-%m-%d"),
        "hydrate":  "probablePitcher,team",
    }
    r = requests.get(f"{MLB_BASE}/schedule", params=params, timeout=15)
    r.raise_for_status()
    out: list[GamePitcher] = []
    for d in r.json().get("dates", []):
        for g in d.get("games", []):
            teams = g.get("teams", {})
            for side, opp_side in [("home", "away"), ("away", "home")]:
                t   = teams.get(side, {})
                opp = teams.get(opp_side, {})
                pp  = t.get("probablePitcher")
                if not pp:
                    continue
                out.append(GamePitcher(
                    pitcher_id  = pp["id"],
                    pitcher_name= pp.get("fullName", "Unknown"),
                    team        = t.get("team", {}).get("abbreviation", "???"),
                    opponent    = opp.get("team", {}).get("abbreviation", "???"),
                    opponent_id = opp.get("team", {}).get("id", 0),
                    handedness  = pp.get("pitchHand", {}).get("code", "R"),
                    home        = (side == "home"),
                    game_pk     = g.get("gamePk"),
                ))
    return out


# ---------------------------------------------------------------------------
# Lineups (today's posted, falling back to predicted from last game)
# ---------------------------------------------------------------------------
def _team_recent_game_pk(team_id: int, target: date,
                         lookback: int = 5) -> Optional[int]:
    """Most recent completed game pk for a team."""
    start = (target - timedelta(days=lookback)).strftime("%Y-%m-%d")
    end   = (target - timedelta(days=1)).strftime("%Y-%m-%d")
    params = {"sportId": 1, "teamId": team_id,
              "startDate": start, "endDate": end}
    try:
        r = requests.get(f"{MLB_BASE}/schedule", params=params, timeout=15)
        r.raise_for_status()
        games = []
        for d in r.json().get("dates", []):
            for g in d.get("games", []):
                if g.get("status", {}).get("abstractGameState") == "Final":
                    games.append(g)
        if not games:
            return None
        return sorted(games, key=lambda g: g.get("gameDate", ""))[-1].get("gamePk")
    except Exception:
        return None


def _fetch_boxscore_lineup(game_pk: int, team_id: int
                          ) -> list[tuple[int, int, str]]:
    """Returns [(player_id, batting_order_position, full_name), ...] or []."""
    try:
        r = requests.get(f"{MLB_BASE}/game/{game_pk}/boxscore", timeout=15)
        r.raise_for_status()
        box = r.json().get("teams", {})
    except Exception:
        return []

    for side in ("home", "away"):
        side_data = box.get(side, {})
        if side_data.get("team", {}).get("id") != team_id:
            continue
        order = side_data.get("battingOrder") or []
        players = side_data.get("players", {})
        out = []
        for i, pid in enumerate(order[:9]):
            pkey = f"ID{pid}"
            name = players.get(pkey, {}).get("person", {}).get("fullName", "Unknown")
            out.append((int(pid), i + 1, name))
        return out
    return []


def get_todays_hitters(pitchers: list[GamePitcher],
                       target_date: date) -> list[GameHitter]:
    """
    For each game, fetch both teams' lineups (or fallback to predicted from
    most recent game).  Each hitter is paired with the OPPOSING starter.
    """
    # group pitchers by game_pk so we know each side's starter
    by_game: dict[int, dict[str, GamePitcher]] = {}
    for p in pitchers:
        by_game.setdefault(p.game_pk, {})
        by_game[p.game_pk]["home" if p.home else "away"] = p

    hitters: list[GameHitter] = []
    team_id_by_abbr = {}  # for translating

    for game_pk, sides in by_game.items():
        # Need team IDs.  Get from MLB API call on this game.
        try:
            r = requests.get(f"{MLB_BASE}/game/{game_pk}/boxscore", timeout=15)
            r.raise_for_status()
            box_teams = r.json().get("teams", {})
            home_id = box_teams.get("home", {}).get("team", {}).get("id")
            away_id = box_teams.get("away", {}).get("team", {}).get("id")
        except Exception as e:
            print(f"  [warn] boxscore fetch failed for {game_pk}: {e}",
                  file=sys.stderr)
            continue

        for side, opp_side in [("home", "away"), ("away", "home")]:
            team_id   = home_id if side == "home" else away_id
            opp_pitch = sides.get(opp_side)
            if opp_pitch is None or team_id is None:
                continue

            lineup = _fetch_boxscore_lineup(game_pk, team_id)
            predicted = False
            if not lineup:
                fallback_pk = _team_recent_game_pk(team_id, target_date)
                if fallback_pk:
                    lineup = _fetch_boxscore_lineup(fallback_pk, team_id)
                    predicted = True
            if not lineup:
                continue

            team_abbr = (sides[side].team if side == "home" else
                         sides[opp_side].opponent)
            opp_abbr  = opp_pitch.team

            for batter_id, order, name in lineup:
                hitters.append(GameHitter(
                    batter_id        = batter_id,
                    batter_name      = name,
                    team             = team_abbr,
                    opponent         = opp_abbr,
                    opp_pitcher_id   = opp_pitch.pitcher_id,
                    opp_pitcher_hand = opp_pitch.handedness,
                    batting_order    = order,
                    home             = (side == "home"),
                    game_pk          = game_pk,
                    lineup_predicted = predicted,
                ))
    return hitters


# ---------------------------------------------------------------------------
# Pitcher rates from Statcast
# ---------------------------------------------------------------------------
def _outs_in_appearance(pa_df: pd.DataFrame) -> int:
    outs = pa_df["events"].isin(OUT_EVENTS).sum()
    outs += pa_df["events"].isin(K_EVENTS).sum()  # K = 1 out
    outs += (pa_df["events"] == "grounded_into_double_play").sum()
    outs += (pa_df["events"] == "strikeout_double_play").sum()
    outs += (pa_df["events"] == "double_play").sum()
    outs += 2 * (pa_df["events"] == "triple_play").sum()
    return int(outs)


def get_pitcher_rates(pitcher_id: int, end: date,
                      league: dict[str, float]) -> PitcherRates:
    start_s = (end - timedelta(days=LOOKBACK_DAYS)).strftime("%Y-%m-%d")
    end_s   = end.strftime("%Y-%m-%d")
    try:
        df = statcast_pitcher(start_s, end_s, pitcher_id)
    except Exception as e:
        print(f"  [warn] pitcher pull failed for {pitcher_id}: {e}",
              file=sys.stderr)
        df = pd.DataFrame()

    if df is None or df.empty:
        return PitcherRates(
            k_rate     = league['k_rate'],
            bb_rate    = league['bb_rate'],
            hr_rate    = league['hr_rate'],
            hits_per_bf= league['1b_rate'] + league['2b_rate'] + league['3b_rate'] + league['hr_rate'],
            era_per_bf = 0.105,                # ~4.5 ERA / 4.3 BF/IP
            avg_ip     = DEFAULT_IP,
            n_bf       = 0,
        )

    pa = pa_terminals(df)
    n_bf = len(pa)

    # Shrunk rates
    def _sr(observed_n, league_rate):
        return ((observed_n + league_rate * PRIOR_BF_PITCHER) /
                (n_bf + PRIOR_BF_PITCHER))

    k_n  = pa["events"].isin(K_EVENTS).sum()
    bb_n = pa["events"].isin(BB_EVENTS).sum()
    hr_n = pa["events"].isin(HR_EVENTS).sum()
    h_n  = (pa["events"].isin(S1_EVENTS).sum() +
            pa["events"].isin(S2_EVENTS).sum() +
            pa["events"].isin(S3_EVENTS).sum() + hr_n)

    league_h_per_bf = (league['1b_rate'] + league['2b_rate'] +
                       league['3b_rate'] + league['hr_rate'])

    # Rolling avg IP per appearance
    games = pa.groupby("game_date")
    outs_per_game = games.apply(_outs_in_appearance, include_groups=False) \
        if hasattr(games, "apply") else pd.Series(dtype=float)
    avg_ip = (outs_per_game.mean() / 3.0) if len(outs_per_game) else DEFAULT_IP

    # ER per BF — use simple proxy: derive from hits + BB allowed and a
    # contact-quality factor (xwOBA could refine this later)
    if "estimated_woba_using_speedangle" in df.columns:
        xwoba = df["estimated_woba_using_speedangle"].dropna().mean()
    else:
        xwoba = 0.320
    if pd.isna(xwoba):
        xwoba = 0.320
    # Heuristic: ER/BF ≈ 0.13 × (xwoba / .320)
    era_per_bf = 0.13 * (float(xwoba) / 0.320)

    return PitcherRates(
        k_rate      = _sr(k_n,  league['k_rate']),
        bb_rate     = _sr(bb_n, league['bb_rate']),
        hr_rate     = _sr(hr_n, league['hr_rate']),
        hits_per_bf = _sr(h_n,  league_h_per_bf),
        era_per_bf  = float(np.clip(era_per_bf, 0.05, 0.25)),
        avg_ip      = float(np.clip(avg_ip, 3.0, 7.5)),
        n_bf        = n_bf,
    )


# ---------------------------------------------------------------------------
# Hitter rates from Statcast
# ---------------------------------------------------------------------------
def get_hitter_rates(batter_id: int, end: date,
                     league: dict[str, float]) -> HitterRates:
    start_s = (end - timedelta(days=LOOKBACK_DAYS)).strftime("%Y-%m-%d")
    end_s   = end.strftime("%Y-%m-%d")
    try:
        df = statcast_batter(start_s, end_s, batter_id)
    except Exception as e:
        print(f"  [warn] batter pull failed for {batter_id}: {e}",
              file=sys.stderr)
        df = pd.DataFrame()

    if df is None or df.empty:
        return HitterRates(
            k_rate=league['k_rate'], bb_rate=league['bb_rate'],
            hr_rate=league['hr_rate'], s1_rate=league['1b_rate'],
            s2_rate=league['2b_rate'], s3_rate=league['3b_rate'],
            bip_out=league['bip_out'],
            rbi_per_pa=0.115, r_per_pa=0.110, n_pa=0,
        )

    pa = pa_terminals(df)
    n_pa = len(pa)

    def _sr(n, lg):
        return ((n + lg * PRIOR_PA_BATTER) / (n_pa + PRIOR_PA_BATTER))

    k_n  = pa["events"].isin(K_EVENTS).sum()
    bb_n = pa["events"].isin(BB_EVENTS).sum()
    hr_n = pa["events"].isin(HR_EVENTS).sum()
    s1_n = pa["events"].isin(S1_EVENTS).sum()
    s2_n = pa["events"].isin(S2_EVENTS).sum()
    s3_n = pa["events"].isin(S3_EVENTS).sum()
    out_n = pa["events"].isin(OUT_EVENTS).sum()

    rates = HitterRates(
        k_rate  = _sr(k_n,  league['k_rate']),
        bb_rate = _sr(bb_n, league['bb_rate']),
        hr_rate = _sr(hr_n, league['hr_rate']),
        s1_rate = _sr(s1_n, league['1b_rate']),
        s2_rate = _sr(s2_n, league['2b_rate']),
        s3_rate = _sr(s3_n, league['3b_rate']),
        bip_out = _sr(out_n, league['bip_out']),
        rbi_per_pa = float(pa.get("rbi", pd.Series([0])).fillna(0).mean()
                          if "rbi" in pa.columns else 0.115),
        r_per_pa   = 0.110,   # placeholder; statcast doesn't give per-PA runs cleanly
        n_pa = n_pa,
    )
    return rates


# ---------------------------------------------------------------------------
# Opponent K% vs handedness (used for pitcher K projections — kept for back-compat)
# ---------------------------------------------------------------------------
def get_opp_k_pct(opp_team_id: int, pitcher_hand: str,
                  end: date, league: dict[str, float]) -> float:
    df = get_league_df(end)
    if df.empty:
        return league['k_rate']
    sub = df[df["p_throws"] == pitcher_hand]
    pa  = pa_terminals(sub)
    if pa.empty:
        return league['k_rate']
    pa["bat_team"] = np.where(pa["inning_topbot"] == "Top",
                              pa["away_team"], pa["home_team"])
    abbr = team_id_to_abbr(opp_team_id)
    team_pa = pa[pa["bat_team"] == abbr]
    if team_pa.empty:
        return league['k_rate']
    return float(team_pa["events"].isin(K_EVENTS).mean())


_team_abbr_cache: dict[int, str] = {}
def team_id_to_abbr(team_id: int) -> str:
    if team_id in _team_abbr_cache:
        return _team_abbr_cache[team_id]
    try:
        r = requests.get(f"{MLB_BASE}/teams/{team_id}", timeout=10)
        r.raise_for_status()
        abbr = r.json()["teams"][0]["abbreviation"]
    except Exception:
        abbr = "???"
    _team_abbr_cache[team_id] = abbr
    return abbr

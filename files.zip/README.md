# MLB Prop Finder (v2)

Pulls today's MLB schedule, projects pitcher AND hitter outcomes for every
common Underdog/sportsbook prop type, and (optionally) compares projections
to user-supplied lines to surface the best +EV plays.

Built for fast iteration. Modular files. Both Underdog pick'em and traditional
sportsbook framings supported.

---

## What's new in v2

- **Hitter projections** (Hits, TB, HR, RBI, R, K, BB, Singles, XBH, HRR)
- **More pitcher props** (Ks, Outs, BB, Hits Allowed, ER)
- **Per-PA Monte Carlo simulation** — 10,000 simulated games per player
- **Lineup fetching** with automatic fallback to last-game's predicted lineup
- **Underdog pick'em framing** alongside sportsbook EV
- **Modular file structure** — extend by adding new prop types

---

## Setup

```bash
git clone https://github.com/gavinfawcett04-jpg/Undergod.git
cd Undergod
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Usage

**Projections only:**
```bash
python3 mlb_prop_finder.py
```

**Get player IDs to build your lines.csv:**
```bash
python3 mlb_prop_finder.py --dump-ids
```

**With your lines:**
```bash
python3 mlb_prop_finder.py --lines lines.csv
```

**Other flags:**
- `--date 2026-04-22` — specific date
- `--pitchers-only` / `--hitters-only` — skip one side
- `--min-edge 0.05` — sportsbook flag threshold (default 5%)
- `--underdog-threshold 0.55` — Underdog flag threshold (default 55%)
- `--n-sims 20000` — more sims = more stable probabilities (slower)

---

## Prop types supported

| Prop type        | Aliases       | Players  |
|------------------|---------------|----------|
| `strikeouts`     | `ks`, `k`     | Both     |
| `walks`          | `bb`          | Both     |
| `hits_allowed`   | `h_allowed`   | Pitchers |
| `outs`           | `pitcher_outs`| Pitchers |
| `earned_runs`    | `er`          | Pitchers |
| `hits`           | `h`           | Hitters  |
| `total_bases`    | `tb`          | Hitters  |
| `home_runs`      | `hr`          | Hitters  |
| `singles`        |               | Hitters  |
| `extra_base_hits`| `xbh`         | Hitters  |
| `rbis`           | `rbi`         | Hitters  |
| `runs`           | `r`           | Hitters  |
| `hits_runs_rbis` | `hrr`         | Hitters  |

## lines.csv format

```
player_id,prop_type,line,over_odds,under_odds
605483,strikeouts,6.5,-115,-105
571448,hits,1.5,,
571448,total_bases,2.5,-110,-110
545361,hrr,2.5,,
```

- **Leave odds blank** for Underdog pick'em (no traditional odds — model just
  projects probability and you decide if it clears your threshold).
- **Fill odds in** for traditional sportsbooks (DraftKings, FanDuel) and
  you'll get sportsbook EV as well.

---

## Methodology

For each starter and each hitter, we pull the last 45 days of Statcast and
shrink the rate stats toward league mean (Bayesian-style) so a hot 2-game
sample doesn't blow up the projection.

**Per-PA outcome model** (7-way multinomial):
```
[K, BB, 1B, 2B, 3B, HR, In-play out]
```

Probabilities for K, BB, HR are computed via **log5** (odds-ratio blend) of
batter, pitcher, and league rates:
```
p(K | B vs P) = (B_K * P_K / L_K) / [B_K*P_K/L_K + (1-B_K)(1-P_K)/(1-L_K)]
```

Remaining probability is split across 1B/2B/3B/Out using the batter's BIP
profile (or the pitcher's contact-quality profile, for pitcher props).

**Game simulation:**
- Hitters: ~65% of PAs vs the starter, ~35% vs league-average bullpen.
  PA count drawn from Poisson(expected_PA) where expected_PA depends on
  batting order.
- Pitchers: BF count drawn from Poisson(avg_IP × 4.3).
- 10,000 simulated games per player, vectorized in numpy.

**Earned runs** are approximated via Poisson(BF × ER_per_BF), where
ER_per_BF is derived from the pitcher's recent xwOBA against. This is the
crudest part of the model — tighten it in v3.

**RBIs and Runs** for hitters use a Poisson approximation off recent rates,
anchored at minimum 1 R + 1 RBI per HR. Lineup-context-aware modeling is
v3 territory.

---

## Two framings: Underdog vs sportsbook

**Sportsbook (DraftKings, FanDuel, etc.):** edge = model_prob − implied_prob.
EV per 1-unit stake printed in the table. ★ flagged at ≥5% edge.

**Underdog Pick'em:** no fixed odds — payouts depend on parlay size. The
relevant question is whether your model probability beats ~55% (the rough
threshold sharp Underdog players use, since 2-pick parlays at 3x payout
break even at ~57.7% per leg). Model probability and edge vs 50% printed.
★ flagged at ≥55%.

---

## Honest caveats — read before betting

**Hitter props are way harder to model than pitcher Ks.**
A pitcher faces ~25 batters; a hitter gets ~4 PAs. A .300 hitter going 0-for-4
vs your "70% to get a hit" projection is a normal Tuesday, not a model failure.
Your sample sizes for evaluating hitter prop performance need to be 3-5x
bigger before drawing any conclusions.

**Other things this model does NOT account for yet:**
- Park factors (huge for HRs and hits in Coors / Petco)
- Weather (cold suppresses Ks slightly, wind direction affects HRs)
- Umpire K-zone (some umps add +5% K rate)
- Bullpen quality (we use league-average; teams vary widely)
- Recent injury or workload (a pitcher coming off 110 pitches throws fewer)
- Batter platoon splits beyond season aggregate
- Specific pitcher arsenal vs batter weakness by pitch type

**Validate before risking real money.** Run for 2-4 weeks, log every projection
and every actual outcome in a CSV, then check calibration: do your "70%"
predictions actually win ~70% of the time? If not, the model is off and you
shouldn't trust it. Skipping this step is how recreational bettors lose money
to lines that look like edges but aren't.

**Predicted lineups (marked with `*`):** before lineups are posted (~2-3 hours
pre-game), the tool falls back to the team's most recent batting order. Often
right but always re-check vs the actual lineup before placing.

---

## File map

```
Undergod/
├── mlb_prop_finder.py    # CLI orchestrator
├── data.py               # MLB Stats API + Statcast fetchers, rate stats
├── simulator.py          # vectorized per-PA Monte Carlo
├── props.py              # prop registry, lines loader, EV math
├── output.py             # formatted table printers
├── requirements.txt
├── sample_lines.csv
└── README.md
```

---

## Roadmap

**v2.1** (next priority)
- Park factor adjustments (a JSON of HR/H multipliers per park)
- Cache the league-wide Statcast pull to a parquet file on disk
- Verbose mode showing the underlying rates that drove each projection

**v2.2**
- Auto-pull lines from [The Odds API](https://the-odds-api.com/) (free tier)
- SQLite logging of every projection vs actual outcome for calibration

**v3**
- Bullpen-specific modeling (each team's bullpen K%/BB%/HR rates)
- Lineup-context-aware RBI/Runs (full game simulation with baserunners)
- Pitch-type-level batter weakness modeling

**v3+** (the actual GM-track move)
- Same engine, repointed at lineup construction (tomorrow's matchup
  projections for our hitters vs the opposing starter). That's a real CSULB
  internship deliverable for Joey.

#!/usr/bin/env python3
"""
MLB Player Prop Finder — v2

Pulls today's MLB schedule, projects pitcher AND hitter outcomes for every
common Underdog/sportsbook prop type, and (optionally) compares projections
to user-supplied lines to surface the best +EV bets.

Usage:
    python mlb_prop_finder.py                              # Today's projections
    python mlb_prop_finder.py --date 2026-04-22            # Specific date
    python mlb_prop_finder.py --lines lines.csv            # Add EV vs lines
    python mlb_prop_finder.py --lines lines.csv --pitchers-only
    python mlb_prop_finder.py --lines lines.csv --hitters-only
    python mlb_prop_finder.py --dump-ids                   # Print all player IDs

Workflow tip:
    1) Run with --dump-ids to get today's player ID list.
    2) Build lines.csv with the props you see on Underdog/DraftKings.
    3) Re-run with --lines lines.csv.
"""

from __future__ import annotations

import argparse
import sys
from datetime import date, datetime

import numpy as np

import data
import simulator as sim
import props
import output


def main() -> int:
    ap = argparse.ArgumentParser(description="MLB prop finder (pitcher + hitter)")
    ap.add_argument("--date",  help="YYYY-MM-DD (default today)")
    ap.add_argument("--lines", help="CSV of prop lines for EV calc")
    ap.add_argument("--min-edge", type=float, default=0.05,
                    help="Sportsbook edge to flag (default 0.05 = 5%%)")
    ap.add_argument("--underdog-threshold", type=float, default=0.55,
                    help="Win prob to flag for Underdog (default 0.55)")
    ap.add_argument("--n-sims", type=int, default=10000,
                    help="Monte Carlo samples per player (default 10000)")
    ap.add_argument("--pitchers-only", action="store_true")
    ap.add_argument("--hitters-only",  action="store_true")
    ap.add_argument("--dump-ids", action="store_true",
                    help="Just print today's player IDs and exit")
    args = ap.parse_args()

    target = (datetime.strptime(args.date, "%Y-%m-%d").date()
              if args.date else date.today())

    print(f"\n=== MLB Prop Finder — {target} ===\n")
    print("Fetching schedule + probable pitchers ...")
    pitchers = data.get_todays_pitchers(target)
    if not pitchers:
        print("No probable pitchers found.")
        return 0
    print(f"  {len(pitchers)} probable starters across {len({p.game_pk for p in pitchers})} games.")

    hitters: list[data.GameHitter] = []
    if not args.pitchers_only:
        print("Fetching lineups (or predicted lineups) ...")
        hitters = data.get_todays_hitters(pitchers, target)
        n_predicted = sum(1 for h in hitters if h.lineup_predicted)
        print(f"  {len(hitters)} hitters loaded "
              f"({n_predicted} from predicted lineups).")

    if args.dump_ids:
        print("\n--- PITCHER IDS ---")
        for p in pitchers:
            print(f"{p.pitcher_id:<10}{p.pitcher_name:<25}{p.team} vs {p.opponent}")
        print("\n--- HITTER IDS ---")
        for h in hitters:
            tag = " (predicted)" if h.lineup_predicted else ""
            print(f"{h.batter_id:<10}{h.batter_name:<25}"
                  f"{h.team} vs {h.opponent}  BO{h.batting_order}{tag}")
        return 0

    print("Computing league baseline rates ...")
    league = data.compute_league_rates(target)
    print(f"  League: K%={league['k_rate']:.1%}, BB%={league['bb_rate']:.1%}, "
          f"HR%={league['hr_rate']:.1%}")

    rng = np.random.default_rng(42)

    # ------------------------------------------------------------------
    # Pitcher projections
    # ------------------------------------------------------------------
    pitcher_rows: list[dict] = []
    pitcher_dists: dict[int, dict[str, np.ndarray]] = {}
    if not args.hitters_only:
        print("\nProjecting pitchers ...")
        for p in pitchers:
            print(f"  {p.pitcher_name} ({p.team})")
            P = data.get_pitcher_rates(p.pitcher_id, target, league)

            # Get opponent lineup-aggregate rates (using opp K% vs handedness
            # as proxy for full opp profile)
            opp_k = data.get_opp_k_pct(p.opponent_id, p.handedness, target, league)
            opp_rates = {
                'k_rate':  opp_k,
                'bb_rate': league['bb_rate'],
                'hr_rate': league['hr_rate'],
            }
            probs = sim.pitcher_pa_probs(P, opp_rates, league)
            expected_bf = P.avg_ip * data.PA_PER_IP
            dist = sim.simulate_pitcher(probs, expected_bf, P.era_per_bf,
                                        n_sims=args.n_sims, rng=rng)
            pitcher_dists[p.pitcher_id] = dist
            pitcher_rows.append({
                'name': p.pitcher_name, 'team': p.team, 'opp': p.opponent,
                'hand': p.handedness, 'ip': P.avg_ip, 'bf': expected_bf,
                'xK':  dist['strikeouts'].mean(),
                'xBB': dist['walks'].mean(),
                'xH':  dist['hits_allowed'].mean(),
                'xER': dist['earned_runs'].mean(),
            })
        output.print_pitcher_projections(pitcher_rows)

    # ------------------------------------------------------------------
    # Hitter projections
    # ------------------------------------------------------------------
    hitter_rows: list[dict] = []
    hitter_dists: dict[int, dict[str, np.ndarray]] = {}
    if not args.pitchers_only and hitters:
        print("\nProjecting hitters ...")
        # Pre-fetch opposing pitcher rates once
        opp_pitcher_rates = {}
        for h in hitters:
            if h.opp_pitcher_id not in opp_pitcher_rates:
                opp_pitcher_rates[h.opp_pitcher_id] = data.get_pitcher_rates(
                    h.opp_pitcher_id, target, league)

        # Use league averages as the bullpen pitcher proxy
        class _BP:
            k_rate  = league['k_rate']
            bb_rate = league['bb_rate']
            hr_rate = league['hr_rate']
            hits_per_bf = (league['1b_rate'] + league['2b_rate']
                           + league['3b_rate'] + league['hr_rate'])
        bullpen_p = _BP()

        for h in hitters:
            B = data.get_hitter_rates(h.batter_id, target, league)
            P = opp_pitcher_rates[h.opp_pitcher_id]

            starter_probs = sim.hitter_pa_probs(B, P, league)
            bullpen_probs = sim.hitter_pa_probs(B, bullpen_p, league)
            exp_pa = sim.expected_pa(h.batting_order)
            dist = sim.simulate_hitter(
                starter_probs, bullpen_probs, exp_pa, B,
                n_sims=args.n_sims, rng=rng)
            hitter_dists[h.batter_id] = dist
            hitter_rows.append({
                'name': h.batter_name, 'team': h.team, 'opp': h.opponent,
                'order': h.batting_order, 'pa': exp_pa,
                'xH':   dist['hits'].mean(),
                'xTB':  dist['total_bases'].mean(),
                'xHR':  dist['home_runs'].mean(),
                'xRBI': dist['rbis'].mean(),
                'xR':   dist['runs'].mean(),
                'xK':   dist['strikeouts'].mean(),
                'predicted': h.lineup_predicted,
            })
        output.print_hitter_projections(hitter_rows)

    # ------------------------------------------------------------------
    # EV vs prop lines
    # ------------------------------------------------------------------
    if args.lines:
        try:
            lines = props.load_lines(args.lines)
        except FileNotFoundError:
            print(f"\nERROR: lines file not found: {args.lines}", file=sys.stderr)
            return 1

        results: list[props.PropResult] = []
        # Build name lookups
        pitcher_lookup = {p.pitcher_id: p for p in pitchers}
        hitter_lookup  = {h.batter_id: h for h in hitters}

        for line in lines:
            dist = None
            name = "Unknown"
            matchup = ""
            if line.player_id in pitcher_dists:
                dist_dict = pitcher_dists[line.player_id]
                p = pitcher_lookup[line.player_id]
                name = p.pitcher_name
                matchup = f"{p.team} vs {p.opponent}"
            elif line.player_id in hitter_dists:
                dist_dict = hitter_dists[line.player_id]
                h = hitter_lookup[line.player_id]
                name = h.batter_name
                matchup = f"{h.team} vs {h.opponent}"
            else:
                print(f"  [warn] no projection for player_id {line.player_id}",
                      file=sys.stderr)
                continue

            if line.prop_type not in dist_dict:
                print(f"  [warn] unknown prop_type '{line.prop_type}' for "
                      f"{name}.  Available: {list(dist_dict.keys())}",
                      file=sys.stderr)
                continue

            dist = dist_dict[line.prop_type]
            results.append(props.evaluate_prop(line, dist, name, matchup,
                                               args.underdog_threshold))

        if results:
            output.print_evaluations(results, args.min_edge,
                                     args.underdog_threshold)
        else:
            print("\nNo lines matched today's player IDs.  Run with "
                  "--dump-ids to get the right IDs.")

    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())

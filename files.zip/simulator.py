"""
simulator.py — Vectorized per-PA Monte Carlo simulation.

Every plate appearance is one of 7 outcomes:
    [0]K  [1]BB  [2]1B  [3]2B  [4]3B  [5]HR  [6]Out_in_play

Outcomes for a player's full game are sampled in numpy arrays of shape
(n_sims, max_pa), then masked down to the actual (random) PA count for
that sim.  This produces distributions over hits, total bases, HRs, etc.
"""

from __future__ import annotations

from typing import Optional

import numpy as np
from scipy.stats import poisson

# Index conventions
IDX_K, IDX_BB, IDX_1B, IDX_2B, IDX_3B, IDX_HR, IDX_OUT = range(7)
TB_VALUES = np.array([0, 0, 1, 2, 3, 4, 0])

DEFAULT_N_SIMS = 10000


def hitter_pa_probs(B, P, L) -> np.ndarray:
    """
    Compute per-PA outcome probabilities for batter B vs pitcher P,
    given league rates L.  Returns shape-(7,) numpy array.

    Uses log5 (odds-ratio) blending for K, BB, HR.  Distributes the
    remaining probability across 1B/2B/3B/Out using the batter's profile.
    """
    def log5(b, p, l):
        if l <= 0 or l >= 1: return b
        num = (b * p) / l
        den = num + ((1 - b) * (1 - p) / (1 - l))
        return num / den if den > 0 else b

    p_K  = log5(B.k_rate,  P.k_rate,  L['k_rate'])
    p_BB = log5(B.bb_rate, P.bb_rate, L['bb_rate'])
    p_HR = log5(B.hr_rate, P.hr_rate, L['hr_rate'])

    # Cap the three head outcomes so remaining > 0
    head = p_K + p_BB + p_HR
    if head >= 0.95:
        scale = 0.95 / head
        p_K, p_BB, p_HR = p_K*scale, p_BB*scale, p_HR*scale
    remaining = 1.0 - p_K - p_BB - p_HR

    # Distribute non-head outcomes using batter's BIP profile
    bip_total = B.s1_rate + B.s2_rate + B.s3_rate + B.bip_out
    if bip_total > 0:
        p_1B  = remaining * (B.s1_rate / bip_total)
        p_2B  = remaining * (B.s2_rate / bip_total)
        p_3B  = remaining * (B.s3_rate / bip_total)
        p_OUT = remaining * (B.bip_out / bip_total)
    else:
        p_1B  = remaining * 0.62
        p_2B  = remaining * 0.20
        p_3B  = remaining * 0.02
        p_OUT = remaining * 0.16

    probs = np.array([p_K, p_BB, p_1B, p_2B, p_3B, p_HR, p_OUT])
    probs = np.clip(probs, 1e-6, None)
    return probs / probs.sum()


def pitcher_pa_probs(P, opp_rates: dict, L: dict) -> np.ndarray:
    """
    Per-PA outcome probabilities for a starter against a generic opposing
    lineup.  opp_rates is the lineup-aggregate rates; L is league baselines.
    """
    def log5(b, p, l):
        if l <= 0 or l >= 1: return b
        num = (b * p) / l
        den = num + ((1 - b) * (1 - p) / (1 - l))
        return num / den if den > 0 else b

    p_K  = log5(opp_rates['k_rate'],  P.k_rate,  L['k_rate'])
    p_BB = log5(opp_rates['bb_rate'], P.bb_rate, L['bb_rate'])
    p_HR = log5(opp_rates['hr_rate'], P.hr_rate, L['hr_rate'])

    head = p_K + p_BB + p_HR
    if head >= 0.95:
        scale = 0.95 / head
        p_K, p_BB, p_HR = p_K*scale, p_BB*scale, p_HR*scale
    remaining = 1.0 - p_K - p_BB - p_HR

    # Distribute remaining using pitcher's hits-on-contact profile blended with league
    p_hits_total = max(0.0, P.hits_per_bf - p_HR)  # singles+doubles+triples per BF
    p_1B = max(0.0, p_hits_total * 0.78)
    p_2B = max(0.0, p_hits_total * 0.20)
    p_3B = max(0.0, p_hits_total * 0.02)
    p_in_play_hits = p_1B + p_2B + p_3B
    if p_in_play_hits > remaining:
        scale = remaining / p_in_play_hits if p_in_play_hits > 0 else 0
        p_1B *= scale; p_2B *= scale; p_3B *= scale
        p_in_play_hits = p_1B + p_2B + p_3B
    p_OUT = remaining - p_in_play_hits

    probs = np.array([p_K, p_BB, p_1B, p_2B, p_3B, p_HR, p_OUT])
    probs = np.clip(probs, 1e-6, None)
    return probs / probs.sum()


# ---------------------------------------------------------------------------
# Expected PA / BF
# ---------------------------------------------------------------------------
PA_BY_BATTING_ORDER = {
    1: 4.65, 2: 4.55, 3: 4.45, 4: 4.32, 5: 4.18,
    6: 4.05, 7: 3.92, 8: 3.80, 9: 3.68,
}

def expected_pa(batting_order: int) -> float:
    return PA_BY_BATTING_ORDER.get(batting_order, 4.0)


# ---------------------------------------------------------------------------
# Simulators
# ---------------------------------------------------------------------------
def simulate_hitter(
    starter_probs: np.ndarray,
    bullpen_probs: np.ndarray,
    expected_pa_total: float,
    rates,                       # HitterRates (for RBI/R per PA)
    pa_vs_starter_share: float = 0.65,
    n_sims: int = DEFAULT_N_SIMS,
    rng: Optional[np.random.Generator] = None,
) -> dict[str, np.ndarray]:
    """Returns distributions across n_sims for one hitter's full game."""
    if rng is None:
        rng = np.random.default_rng()
    max_pa = 7
    pa_counts = np.clip(rng.poisson(expected_pa_total, n_sims), 1, max_pa)

    # Split: first ceil(pa_vs_starter_share * pa) PAs vs starter, rest vs bullpen
    pa_starter = np.minimum(pa_counts,
        np.ceil(pa_vs_starter_share * pa_counts).astype(int))
    pa_bullpen = pa_counts - pa_starter

    # Generate starter outcomes
    out_starter = rng.choice(7, size=(n_sims, max_pa), p=starter_probs)
    out_bullpen = rng.choice(7, size=(n_sims, max_pa), p=bullpen_probs)
    idx = np.arange(max_pa)[None, :]
    mask_starter = idx < pa_starter[:, None]
    mask_bullpen = (idx >= pa_starter[:, None]) & (idx < pa_counts[:, None])

    def count(arr_a, arr_b, target_set, mask_a, mask_b) -> np.ndarray:
        a = np.isin(arr_a, list(target_set)) & mask_a
        b = np.isin(arr_b, list(target_set)) & mask_b
        return a.sum(axis=1) + b.sum(axis=1)

    hits_targets = {IDX_1B, IDX_2B, IDX_3B, IDX_HR}
    hits = count(out_starter, out_bullpen, hits_targets, mask_starter, mask_bullpen)
    hrs  = count(out_starter, out_bullpen, {IDX_HR}, mask_starter, mask_bullpen)
    s1s  = count(out_starter, out_bullpen, {IDX_1B}, mask_starter, mask_bullpen)
    xbh  = count(out_starter, out_bullpen, {IDX_2B, IDX_3B, IDX_HR},
                 mask_starter, mask_bullpen)
    ks   = count(out_starter, out_bullpen, {IDX_K}, mask_starter, mask_bullpen)
    bbs  = count(out_starter, out_bullpen, {IDX_BB}, mask_starter, mask_bullpen)

    tb_starter = (TB_VALUES[out_starter] * mask_starter).sum(axis=1)
    tb_bullpen = (TB_VALUES[out_bullpen] * mask_bullpen).sum(axis=1)
    tb = tb_starter + tb_bullpen

    # RBI / R: Poisson approximation per PA using player's recent rate.
    # Anchor at minimum from HRs (each HR gives ≥1 RBI and 1 R).
    expected_rbi_extra = max(0.0, rates.rbi_per_pa * expected_pa_total - hrs.mean())
    expected_r_extra   = max(0.0, rates.r_per_pa   * expected_pa_total - hrs.mean())
    rbi_extra = rng.poisson(expected_rbi_extra, n_sims)
    r_extra   = rng.poisson(expected_r_extra, n_sims)
    rbis = hrs + rbi_extra
    runs = hrs + r_extra

    return {
        'hits':        hits,
        'home_runs':   hrs,
        'singles':     s1s,
        'extra_base_hits': xbh,
        'total_bases': tb,
        'strikeouts':  ks,
        'walks':       bbs,
        'rbis':        rbis,
        'runs':        runs,
        'hits_runs_rbis': hits + rbis + runs,
    }


def simulate_pitcher(
    pa_probs: np.ndarray,
    expected_bf: float,
    era_per_bf: float,
    n_sims: int = DEFAULT_N_SIMS,
    rng: Optional[np.random.Generator] = None,
) -> dict[str, np.ndarray]:
    if rng is None:
        rng = np.random.default_rng()
    max_bf = 35
    bf_counts = np.clip(rng.poisson(expected_bf, n_sims), 8, max_bf)
    outcomes = rng.choice(7, size=(n_sims, max_bf), p=pa_probs)
    idx  = np.arange(max_bf)[None, :]
    mask = idx < bf_counts[:, None]

    ks   = ((outcomes == IDX_K)  & mask).sum(axis=1)
    bbs  = ((outcomes == IDX_BB) & mask).sum(axis=1)
    hits = (((outcomes >= IDX_1B) & (outcomes <= IDX_HR)) & mask).sum(axis=1)
    bip_outs = ((outcomes == IDX_OUT) & mask).sum(axis=1)
    outs = ks + bip_outs
    ers  = rng.poisson(bf_counts * era_per_bf)

    return {
        'strikeouts':   ks,
        'walks':        bbs,
        'hits_allowed': hits,
        'outs':         outs,
        'earned_runs':  ers,
    }
